//
//  TenmatesUIApp.swift
//  TenmatesUI
//
//  Created by Shaik Areef on 17/02/25.
//

import SwiftUI

@main
struct TenmatesUIApp: App {
    var body: some Scene {
        WindowGroup {
            EventView()
        }
    }
}
